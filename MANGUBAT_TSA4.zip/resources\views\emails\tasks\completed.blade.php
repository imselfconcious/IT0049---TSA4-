# Task completed

The task **{{ $task->title }}** has been marked as done.

@if($task->description)
> {{ $task->description }}
@endif

Thank you for keeping your day moving.
