<?php

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function (): void {
    Route::view('/login', 'auth.login')->name('login');
    Route::post('/login', function (): mixed { $credentials = request()->validate(['email'=>'required|email','password'=>'required']); if (Auth::attempt($credentials, request()->boolean('remember'))) { request()->session()->regenerate(); return to_route('tasks.index'); } return back()->withErrors(['email'=>'The provided credentials are incorrect.'])->onlyInput('email'); });
    Route::view('/register', 'auth.register')->name('register');
    Route::post('/register', function (): mixed { $data = request()->validate(['name'=>'required|string|max:255','email'=>'required|email|max:255|unique:users','password'=>'required|confirmed|min:8']); $user=User::create($data); Auth::login($user); return to_route('tasks.index'); });
});
Route::post('/logout', function (): mixed { Auth::logout(); request()->session()->invalidate(); request()->session()->regenerateToken(); return to_route('home'); })->middleware('auth')->name('logout');
