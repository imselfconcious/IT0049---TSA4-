<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void { Schema::create('tasks', function (Blueprint $table): void { $table->id(); $table->string('title'); $table->text('description')->nullable(); $table->date('due_date')->nullable(); $table->string('priority')->default('medium'); $table->string('status')->default('pending'); $table->boolean('is_archived')->default(false); $table->timestamps(); }); }
    public function down(): void { Schema::dropIfExists('tasks'); }
};
