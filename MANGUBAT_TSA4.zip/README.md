# Tasks for Today — Laravel TSA4

A full CRUD task manager rebuilt in Laravel 13 with Breeze-compatible authentication and a completion email notification.

## Features

- Public Welcome, Task List, Profile/auth, and About pages.
- Authenticated users can create, update, and archive tasks.
- Validation for title, description, due date, priority, and status.
- Soft deletion through `is_archived`; archived tasks do not appear in the list.
- `TaskCompleted` Mailable sends only when a task transitions into `done`.
- Default mailer is `log`, so no real email is sent. Inspect `storage/logs/laravel.log` after completion.
- SQLite database, migration, factory, and demo seeder included.

## Setup

Requirements: PHP 8.3+, Composer, Node.js 20+, and npm.

```bash
composer install
cp .env.example .env   # Windows PowerShell: Copy-Item .env.example .env
php artisan key:generate
New-Item database/database.sqlite -ItemType File -Force
php artisan migrate --seed
npm install
npm run build
php artisan serve
```

Demo account: `demo@example.com` / `password`.

For email verification, keep `MAIL_MAILER=log` and set `TASK_NOTIFICATION_EMAIL` in `.env`. Mark a pending task as done, then inspect `storage/logs/laravel.log`. Updating a task already marked done does not send a second message. For a safe SMTP sandbox, replace the mail variables with credentials from Mailtrap or another test SMTP provider.

## Tests

```bash
php artisan test
```

The feature tests cover both the first pending-to-done transition and the no-resend behavior for an already-done task.

## Hosting / submission

Deploy the repository to a PHP-capable host, configure its environment variables, run migrations, and use the host's public URL for the assignment submission. This local deliverable does not create a GitHub repository or hosted service because those actions require the student's accounts and deployment credentials.
