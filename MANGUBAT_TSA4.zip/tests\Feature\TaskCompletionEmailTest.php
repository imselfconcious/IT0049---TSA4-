<?php

namespace Tests\Feature;

use App\Mail\TaskCompleted;
use App\Models\Task;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class TaskCompletionEmailTest extends TestCase
{
    use RefreshDatabase;
    public function test_transition_to_done_sends_one_email(): void { Mail::fake(); $user=User::factory()->create(); $task=Task::factory()->create(['status'=>'pending']); $this->actingAs($user)->put(route('tasks.update',$task), ['title'=>$task->title,'description'=>'x','priority'=>'medium','status'=>'done']); Mail::assertSent(TaskCompleted::class,1); }
    public function test_already_done_task_does_not_send_again(): void { Mail::fake(); $user=User::factory()->create(); $task=Task::factory()->create(['status'=>'done']); $this->actingAs($user)->put(route('tasks.update',$task), ['title'=>$task->title,'description'=>'x','priority'=>'medium','status'=>'done']); Mail::assertNothingSent(); }
}
