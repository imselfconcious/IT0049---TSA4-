<?php

namespace App\Http\Controllers;

use App\Mail\TaskCompleted;
use App\Models\Task;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;

class TaskController extends Controller
{
    public function index(): View { return view('tasks.index', ['tasks' => Task::where('is_archived', false)->latest()->paginate(10)]); }
    public function create(): View { return view('tasks.create', ['task' => new Task(['priority' => 'medium', 'status' => 'pending'])]); }
    public function store(Request $request): RedirectResponse
    {
        Task::create($this->validated($request));
        return to_route('tasks.index')->with('success', 'Task created successfully.');
    }
    public function edit(Task $task): View { abort_if($task->is_archived, 404); return view('tasks.edit', compact('task')); }
    public function update(Request $request, Task $task): RedirectResponse
    {
        abort_if($task->is_archived, 404);
        $wasDone = $task->status === 'done';
        $data = $this->validated($request);
        $task->update($data);
        if (!$wasDone && $task->status === 'done') {
            Mail::to(config('tasks.notification_recipient'))->send(new TaskCompleted($task));
        }
        return to_route('tasks.index')->with('success', 'Task updated successfully.');
    }
    public function destroy(Task $task): RedirectResponse
    {
        $task->update(['is_archived' => true]);
        return to_route('tasks.index')->with('success', 'Task archived successfully.');
    }
    private function validated(Request $request): array
    {
        return $request->validate(['title' => ['required','string','max:120'], 'description' => ['nullable','string','max:2000'], 'due_date' => ['nullable','date'], 'priority' => ['required','in:low,medium,high'], 'status' => ['required','in:pending,in_progress,done']]);
    }
}
